/**
 * @file admin-engine.js
 * @description Deprecated. Data logic moved to API.
 */
console.warn("admin-engine.js is deprecated. Please use api.js and AdminController.");
