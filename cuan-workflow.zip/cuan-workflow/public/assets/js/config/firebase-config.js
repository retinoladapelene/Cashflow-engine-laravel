/**
 * @file firebase-config.js
 * @description Deprecated. App now uses Laravel API + MySQL.
 */
// export const db = ...; 
console.log("Firebase is disabled.");
